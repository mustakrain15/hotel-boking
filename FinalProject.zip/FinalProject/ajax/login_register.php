<?php
require('../adminpanel/inc/connection.php');
require('../adminpanel/inc/essentials.php');
// use PHPMailer\PHPMailer\PHPMailer;
// use PHPMailer\PHPMailer\SMTP;
// use PHPMailer\PHPMailer\Exception;

// //Load Composer's autoloader
// require ('mailer/Exception.php');
// require ('mailer/PHPMailer.php');
// require ('mailer/SMTP.php');

// function send_mail($uemail,$name,$token){
//     $mail = new PHPMailer(true);

// try {
//     //Server settings
//     $mail->isSMTP();                                            //Send using SMTP
//     $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
//     $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
//     $mail->Username   = 'bhell1510@gmail.com';                     //SMTP username
//     $mail->Password   = 'hinausad';                               //SMTP password
//     $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
//     $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

//     //Recipients
//     $mail->setFrom('bhell1510@gmail.com', 'Rain Hotel');
//     $mail->addAddress('bhell1510@gmail.com');     //Add a recipient
    
//     //Content
//     $mail->isHTML(true);                                  //Set email format to HTML
//     $mail->Subject = 'Testing PHPMailer';
//     $mail->Body    = "Click the link to confirm you email: <br>
//                         <a href='".SITE_URL."email_confirm.php?email=$uemail&token=$token"."'>CLICK ME</a>";
//     $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

//     $mail->send();
//     echo 'Message has been sent';
// } catch (Exception $e) {
//     echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
// }
// }

if(isset($_POST['register'])){
    $data = filteration($_POST);
    // match password and confirm password field
    if($data['pass'] != $data['cpass']){
        echo'pass_mismatch';
        exit;
    } 
    // check user exists or not
    $u_exit = select("SELECT * FROM `user_cred` WHERE `email`=? 
    AND `phonenum`=? LIMIT 1",[$data['email'],$data['phonenum']],"ss");
    if(mysqli_num_rows($u_exit)!=0){
        $u_exit_fetch = mysqli_fetch_assoc($u_exit);
        echo ($u_exit_fetch['email'] == $data['email']) ? 'email_already' : 'phone_already';
        exit;
    }
    // upload user image to server

    $img = uploadUserImage($_FILES['profile']);
    if($img == 'inv_img'){
        echo 'inv_img';
        exit;
    }
    else if($img == 'upd_failed'){
        echo 'upd_failed';
        exit;
    }

    // send confirmation link to user's email0
//     $token = bin2hex(random_bytes(16));
// if(!send_mail($data['email'],$data['name'],$token)){
//     echo 'mail_failed';
//     exit;
// }
$enc_pass= password_hash($data['pass'],PASSWORD_BCRYPT);
$query = "INSERT INTO `user_cred`(`name`, `email`, `address`, `phonenum`, `pincode`, `dob`, `profile`, `password`) VALUES (?,?,?,?,?,?,?,?)";
$values = [$data['name'],$data['email'],$data['address'],$data['phonenum'],$data['pincode'],$data['dob'],$img,$enc_pass];

if(insert($query,$values,'ssssssss')){
    echo 1;
}
else{
    echo 'upd_failed';
    exit;
}

}
?>